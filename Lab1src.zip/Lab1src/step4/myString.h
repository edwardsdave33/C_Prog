// MYSTRING.H
// Code provided for ELEC278 Lab 1 Step 4
// Prototypes for the functions found in MYSTRING.C

char *copyString(char *s);
void printString(char *s);
